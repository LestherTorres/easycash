<?php
class Database {
    private static $instance = null;
    private $conn;

    private function __construct() {
        $host = 'auth-db1349.hstgr.io';
        $db_user = 'u942601817_cash';
        $db_password = 'Josue1995.@';
        $db_name = 'u942601817_CASH';
        $port = 3306;

        mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

        try {
            $this->conn = mysqli_init();
            if (!$this->conn) {
                throw new Exception("mysqli_init failed");
            }

            mysqli_options($this->conn, MYSQLI_OPT_CONNECT_TIMEOUT, 10);

            if (!mysqli_real_connect($this->conn, $host, $db_user, $db_password, $db_name, $port)) {
                throw new Exception("Connect Error (" . mysqli_connect_errno() . ") " . mysqli_connect_error());
            }

            $this->conn->set_charset("utf8mb4");
        } catch (Exception $e) {
            die("Error de conexión: " . $e->getMessage());
        }
    }

    public static function getInstance() {
        if (self::$instance == null) {
            self::$instance = new Database();
        }
        return self::$instance;
    }

    public function getConnection() {
        return $this->conn;
    }
}
