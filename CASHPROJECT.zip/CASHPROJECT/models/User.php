<?php
require_once 'config/database.php';

class User {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }

    public function verifyUser($nombre, $contrasena) {
        try {
            $query = "SELECT * FROM USUARIOS WHERE Nombre = ?";
            $stmt = $this->db->prepare($query);
            if (!$stmt) {
                throw new Exception("Error preparing statement: " . $this->db->error);
            }
            $stmt->bind_param("s", $nombre);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows == 1) {
                $user = $result->fetch_assoc();
                // Usamos password_verify para comparar la contraseña ingresada con el hash almacenado
                if (password_verify($contrasena, $user['Contraseña'])) {
                    return [
                        'id' => $user['ID'],
                        'nombre' => $user['Nombre'],
                        'rol' => $user['Rol']
                    ];
                }
            }
            return false;
        } catch (Exception $e) {
            error_log("Error in verifyUser: " . $e->getMessage());
            throw $e;
        }
    }
}
