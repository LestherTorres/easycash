<?php
session_start();
require_once 'config/database.php';

// Verificar si el usuario está logueado
if (!isset($_SESSION['user'])) {
    header('Location: index.php');
    exit();
}

$db = Database::getInstance()->getConnection();

// Obtener todos los clientes
$query = "SELECT * FROM creditos";
$result = $db->query($query);
$clientes = $result->fetch_all(MYSQLI_ASSOC);

// Obtener días de pago únicos
$dias_pago = array_unique(array_column($clientes, 'dia_de_pago'));
sort($dias_pago);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clientes</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">Mi Aplicación</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="#">Clientes</a>
                    </li>
                </ul>
                <a href="logout.php" class="btn btn-outline-light">Cerrar Sesión</a>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <h1 class="mb-4">Clientes</h1>
        
        <div class="row mb-4">
            <div class="col-md-6">
                <input type="text" id="searchCliente" class="form-control" placeholder="Buscar cliente...">
            </div>
            <div class="col-md-6">
                <select id="filterDiaPago" class="form-select">
                    <option value="">Filtrar por día de pago</option>
                    <?php foreach ($dias_pago as $dia): ?>
                        <option value="<?php echo htmlspecialchars($dia); ?>"><?php echo htmlspecialchars($dia); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
        
        <div class="table-responsive">
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Datos Cliente</th>
                        <th>Cantidad Financiada</th>
                        <th>Saldo Actual</th>
                        <th>Valor Cuota</th>
                        <th>Estado Crédito</th>
                        <th>Día de Pago</th>
                    </tr>
                </thead>
                <tbody id="clientesTableBody">
                    <?php foreach ($clientes as $cliente): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($cliente['id']); ?></td>
                        <td><?php echo htmlspecialchars($cliente['datos_cliente']); ?></td>
                        <td><?php echo htmlspecialchars($cliente['cantidad_financiada']); ?></td>
                        <td><?php echo htmlspecialchars($cliente['saldo_actual']); ?></td>
                        <td><?php echo htmlspecialchars($cliente['valor_cuota']); ?></td>
                        <td><?php echo htmlspecialchars($cliente['estado_credito']); ?></td>
                        <td><?php echo htmlspecialchars($cliente['dia_de_pago']); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const searchInput = document.getElementById('searchCliente');
            const filterSelect = document.getElementById('filterDiaPago');
            const tableBody = document.getElementById('clientesTableBody');
            const rows = tableBody.getElementsByTagName('tr');

            function filterTable() {
                const searchTerm = searchInput.value.toLowerCase();
                const filterDay = filterSelect.value.toLowerCase();

                for (let row of rows) {
                    const clienteData = row.cells[1].textContent.toLowerCase();
                    const diaPago = row.cells[6].textContent.toLowerCase();
                    
                    const matchesSearch = clienteData.includes(searchTerm);
                    const matchesFilter = filterDay === '' || diaPago === filterDay;

                    row.style.display = (matchesSearch && matchesFilter) ? '' : 'none';
                }
            }

            searchInput.addEventListener('input', filterTable);
            filterSelect.addEventListener('change', filterTable);
        });
    </script>
</body>
</html>