<?php
require_once 'controllers/LoginController.php';

$action = isset($_GET['action']) ? $_GET['action'] : 'index';

$controller = new LoginController();

switch ($action) {
    case 'index':
        $controller->index();
        break;
    case 'authenticate':
        $controller->authenticate();
        break;
    default:
        // Manejar 404 o redirigir a la página de inicio
        header('Location: index.php');
        break;
}
