<?php
require_once 'models/User.php';

class LoginController {
    private $userModel;

    public function __construct() {
        $this->userModel = new User();
    }

    public function index() {
        require_once 'views/login.php';
    }

    public function authenticate() {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $nombre = $_POST['nombre'];
            $contrasena = $_POST['contrasena'];

            try {
                $user = $this->userModel->verifyUser($nombre, $contrasena);
                if ($user) {
                    session_start();
                    $_SESSION['user'] = $user;
                    header('Location: dashboard.php');
                } else {
                    header('Location: index.php?error=1');
                }
            } catch (Exception $e) {
                error_log("Error in authentication: " . $e->getMessage());
                header('Location: index.php?error=2');
            }
        }
    }
}
